webpackHotUpdate("app",{

/***/ "./node_modules/axios/index.js":
false,

/***/ "./node_modules/axios/lib/adapters/xhr.js":
false,

/***/ "./node_modules/axios/lib/axios.js":
false,

/***/ "./node_modules/axios/lib/cancel/Cancel.js":
false,

/***/ "./node_modules/axios/lib/cancel/CancelToken.js":
false,

/***/ "./node_modules/axios/lib/cancel/isCancel.js":
false,

/***/ "./node_modules/axios/lib/core/Axios.js":
false,

/***/ "./node_modules/axios/lib/core/InterceptorManager.js":
false,

/***/ "./node_modules/axios/lib/core/buildFullPath.js":
false,

/***/ "./node_modules/axios/lib/core/createError.js":
false,

/***/ "./node_modules/axios/lib/core/dispatchRequest.js":
false,

/***/ "./node_modules/axios/lib/core/enhanceError.js":
false,

/***/ "./node_modules/axios/lib/core/mergeConfig.js":
false,

/***/ "./node_modules/axios/lib/core/settle.js":
false,

/***/ "./node_modules/axios/lib/core/transformData.js":
false,

/***/ "./node_modules/axios/lib/defaults.js":
false,

/***/ "./node_modules/axios/lib/env/data.js":
false,

/***/ "./node_modules/axios/lib/helpers/bind.js":
false,

/***/ "./node_modules/axios/lib/helpers/buildURL.js":
false,

/***/ "./node_modules/axios/lib/helpers/combineURLs.js":
false,

/***/ "./node_modules/axios/lib/helpers/cookies.js":
false,

/***/ "./node_modules/axios/lib/helpers/isAbsoluteURL.js":
false,

/***/ "./node_modules/axios/lib/helpers/isAxiosError.js":
false,

/***/ "./node_modules/axios/lib/helpers/isURLSameOrigin.js":
false,

/***/ "./node_modules/axios/lib/helpers/normalizeHeaderName.js":
false,

/***/ "./node_modules/axios/lib/helpers/parseHeaders.js":
false,

/***/ "./node_modules/axios/lib/helpers/spread.js":
false,

/***/ "./node_modules/axios/lib/helpers/validator.js":
false,

/***/ "./node_modules/axios/lib/utils.js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/components/quiz/RoundTransition.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/NotFound.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/login.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/QuizDetails.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/components/quiz/RoundTransition.vue?vue&type=template&id=6c958939":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/NotFound.vue?vue&type=template&id=5488b41e":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/login.vue?vue&type=template&id=b3bf4462&scoped=true":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/QuizDetails.vue?vue&type=template&id=6aa12990":
false,

/***/ "./node_modules/core-js/modules/es.array.slice.js":
false,

/***/ "./node_modules/core-js/modules/web.dom-collections.iterator.js":
false,

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/login.vue?vue&type=style&index=0&id=b3bf4462&scoped=true&lang=css":
false,

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/QuizDetails.vue?vue&type=style&index=0&id=6aa12990&lang=css":
false,

/***/ "./node_modules/node-libs-browser/mock/process.js":
false,

/***/ "./node_modules/path-browserify/index.js":
false,

/***/ "./node_modules/vue-router/dist/vue-router.esm-bundler.js":
false,

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/login.vue?vue&type=style&index=0&id=b3bf4462&scoped=true&lang=css":
false,

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/QuizDetails.vue?vue&type=style&index=0&id=6aa12990&lang=css":
false,

/***/ "./router/index.js":
/*!*************************!*\
  !*** ./router/index.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed (from ./node_modules/babel-loader/lib/index.js):\\nSyntaxError: C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\router\\\\index.js: Unexpected token (5:0)\\n\\n\\u001b[0m \\u001b[90m 3 |\\u001b[39m \\u001b[36mimport\\u001b[39m \\u001b[33mNotFound\\u001b[39m \\u001b[36mfrom\\u001b[39m \\u001b[32m'../views/NotFound.vue'\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 4 |\\u001b[39m \\u001b[36mimport\\u001b[39m \\u001b[33mQuizDetails\\u001b[39m \\u001b[36mfrom\\u001b[39m \\u001b[0m\\n\\u001b[0m\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 5 |\\u001b[39m \\u001b[36mimport\\u001b[39m store \\u001b[36mfrom\\u001b[39m \\u001b[32m'../store/store.js'\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m   |\\u001b[39m \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 6 |\\u001b[39m \\u001b[36mimport\\u001b[39m \\u001b[33mLogin\\u001b[39m \\u001b[36mfrom\\u001b[39m \\u001b[32m'../views/accounts/login.vue'\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 7 |\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 8 |\\u001b[39m \\u001b[90m//function lazyLoad(view){\\u001b[39m\\u001b[0m\\n    at Object._raise (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:476:17)\\n    at Object.raiseWithData (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:469:17)\\n    at Object.raise (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:430:17)\\n    at Object.unexpected (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:3789:16)\\n    at Object.parseImportSource (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:15725:32)\\n    at Object.parseImport (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:15707:24)\\n    at Object.parseStatementContent (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:14223:27)\\n    at Object.parseStatement (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:14113:17)\\n    at Object.parseBlockOrModuleBlockBody (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:14739:25)\\n    at Object.parseBlockBody (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:14730:10)\\n    at Object.parseProgram (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:14032:10)\\n    at Object.parseTopLevel (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:14019:25)\\n    at Object.parse (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:15940:10)\\n    at parse (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:15967:26)\\n    at parser (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\core\\\\lib\\\\parser\\\\index.js:52:34)\\n    at parser.next (<anonymous>)\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yb3V0ZXIvaW5kZXguanMuanMiLCJzb3VyY2VzIjpbXSwibWFwcGluZ3MiOiIiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./router/index.js\n");

/***/ }),

/***/ "./src/components/quiz/RoundTransition.vue":
false,

/***/ "./src/components/quiz/RoundTransition.vue?vue&type=script&lang=js":
false,

/***/ "./src/components/quiz/RoundTransition.vue?vue&type=template&id=6c958939":
false,

/***/ "./views/NotFound.vue":
false,

/***/ "./views/NotFound.vue?vue&type=script&lang=js":
false,

/***/ "./views/NotFound.vue?vue&type=template&id=5488b41e":
false,

/***/ "./views/accounts/login.vue":
false,

/***/ "./views/accounts/login.vue?vue&type=script&lang=js":
false,

/***/ "./views/accounts/login.vue?vue&type=style&index=0&id=b3bf4462&scoped=true&lang=css":
false,

/***/ "./views/accounts/login.vue?vue&type=template&id=b3bf4462&scoped=true":
false,

/***/ "./views/quizes/QuizDetails.vue":
false,

/***/ "./views/quizes/QuizDetails.vue?vue&type=script&lang=js":
false,

/***/ "./views/quizes/QuizDetails.vue?vue&type=style&index=0&id=6aa12990&lang=css":
false,

/***/ "./views/quizes/QuizDetails.vue?vue&type=template&id=6aa12990":
false

})