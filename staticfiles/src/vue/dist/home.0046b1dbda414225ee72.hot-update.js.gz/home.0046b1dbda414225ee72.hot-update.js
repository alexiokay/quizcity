webpackHotUpdate("home",{

/***/ "./node_modules/core-js/internals/array-for-each.js":
false,

/***/ "./node_modules/core-js/internals/array-method-is-strict.js":
false,

/***/ "./node_modules/core-js/internals/correct-is-regexp-logic.js":
false,

/***/ "./node_modules/core-js/internals/create-property.js":
false,

/***/ "./node_modules/core-js/internals/is-regexp.js":
false,

/***/ "./node_modules/core-js/internals/not-a-regexp.js":
false,

/***/ "./node_modules/core-js/internals/regexp-flags.js":
false,

/***/ "./node_modules/core-js/modules/es.regexp.to-string.js":
false,

/***/ "./node_modules/core-js/modules/web.dom-collections.for-each.js":
false

})