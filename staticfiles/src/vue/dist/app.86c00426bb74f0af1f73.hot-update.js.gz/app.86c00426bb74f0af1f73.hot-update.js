webpackHotUpdate("app",{

/***/ "./store/store.js":
/*!************************!*\
  !*** ./store/store.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ \"./node_modules/vuex/dist/vuex.esm-browser.js\");\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (Object(vuex__WEBPACK_IMPORTED_MODULE_0__[\"createStore\"])({\n  state: function state() {\n    return {\n      count: 0,\n      categories: [],\n      modalConfirm: null,\n      searchResults: [],\n      searchIn: [],\n      authenticated: false,\n      username: \"\",\n      searching: false,\n      day: true,\n      user: {\n        \"username\": \"\",\n        \"token\": \"\",\n        \"friends\": []\n      },\n      //quiz game mind\n      questions: []\n    };\n  },\n  mutations: {\n    increment: function increment(state) {\n      state.count += 110;\n    }\n  }\n}));//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9zdG9yZS5qcy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3N0b3JlL3N0b3JlLmpzPzQyYTIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlU3RvcmUgfSBmcm9tICd2dWV4J1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNyZWF0ZVN0b3JlKHtcclxuICBzdGF0ZSAoKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBjb3VudDogMCxcclxuICAgICAgY2F0ZWdvcmllczogW10sXHJcbiAgICAgIG1vZGFsQ29uZmlybTogbnVsbCxcclxuICAgICAgc2VhcmNoUmVzdWx0czogW10sXHJcbiAgICAgIHNlYXJjaEluOiBbXSxcclxuICAgICAgYXV0aGVudGljYXRlZDogZmFsc2UsXHJcbiAgICAgIHVzZXJuYW1lOiBcIlwiLFxyXG4gICAgICBzZWFyY2hpbmc6IGZhbHNlLFxyXG4gICAgICBkYXk6IHRydWUsXHJcbiAgICAgIHVzZXI6IHtcclxuICAgICAgICBcInVzZXJuYW1lXCI6IFwiXCIsXHJcbiAgICAgICAgXCJ0b2tlblwiOiBcIlwiLFxyXG4gICAgICAgIFwiZnJpZW5kc1wiOiBbXHJcbiAgICAgICAgICBcclxuICAgICAgICBdLFxyXG5cclxuICAgICAgfSxcclxuXHJcbiAgICAgIC8vcXVpeiBnYW1lIG1pbmRcclxuICAgICAgcXVlc3Rpb25zOiBbXSxcclxuICAgICAgXHJcbiAgICB9XHJcbiAgfSxcclxuICBcclxuICBtdXRhdGlvbnM6IHtcclxuICAgIGluY3JlbWVudCAoc3RhdGUpIHtcclxuICAgICAgc3RhdGUuY291bnQgKz0gMTEwXHJcbiAgICB9LFxyXG4gIH1cclxufSkiXSwibWFwcGluZ3MiOiJBQUFBO0FBQUE7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFTQTtBQUNBO0FBcEJBO0FBdUJBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQTNCQSIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./store/store.js\n");

/***/ })

})