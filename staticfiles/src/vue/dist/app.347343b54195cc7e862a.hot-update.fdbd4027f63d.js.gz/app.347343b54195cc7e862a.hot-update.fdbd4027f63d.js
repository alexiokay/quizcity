webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Home.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Notifications.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/Profile.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/Quizes.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Home.vue?vue&type=template&id=2f2be7e4":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Notifications.vue?vue&type=template&id=cf555d6e":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/Profile.vue?vue&type=template&id=03d2b722":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/Quizes.vue?vue&type=template&id=9b13c6a0":
false,

/***/ "./node_modules/core-js/internals/array-slice-simple.js":
false,

/***/ "./node_modules/core-js/internals/define-well-known-symbol.js":
false,

/***/ "./node_modules/core-js/internals/object-get-own-property-names-external.js":
false,

/***/ "./node_modules/core-js/internals/path.js":
false,

/***/ "./node_modules/core-js/internals/well-known-symbol-wrapped.js":
false,

/***/ "./node_modules/core-js/modules/es.array.includes.js":
false,

/***/ "./node_modules/core-js/modules/es.string.includes.js":
false,

/***/ "./node_modules/core-js/modules/es.symbol.description.js":
false,

/***/ "./node_modules/core-js/modules/es.symbol.js":
false,

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/Quizes.vue?vue&type=style&index=0&id=9b13c6a0&lang=css":
false,

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/Quizes.vue?vue&type=style&index=0&id=9b13c6a0&lang=css":
false,

/***/ "./router/index.js":
/*!*************************!*\
  !*** ./router/index.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ \"./node_modules/core-js/modules/es.object.to-string.js\");\n/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ \"./node_modules/core-js/modules/es.string.iterator.js\");\n/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ \"./node_modules/core-js/modules/web.dom-collections.iterator.js\");\n/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-router */ \"./node_modules/vue-router/dist/vue-router.esm-bundler.js\");\n/* harmony import */ var _views_quizes_AddQuiz_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../views/quizes/AddQuiz.vue */ \"./views/quizes/AddQuiz.vue\");\n/* harmony import */ var _views_NotFound_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../views/NotFound.vue */ \"./views/NotFound.vue\");\n/* harmony import */ var _views_quizes_QuizDetails_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../views/quizes/QuizDetails.vue */ \"./views/quizes/QuizDetails.vue\");\n/* harmony import */ var _store_store_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../store/store.js */ \"./store/store.js\");\n/* harmony import */ var _views_accounts_login_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../views/accounts/login.vue */ \"./views/accounts/login.vue\");\n/* harmony import */ var _views_Features_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../views/Features.vue */ \"./views/Features.vue\");\n\n\n\n //import Home from '../views/Home.vue'\n\n\n\n\n\n //import Profile from '../views/accounts/Profile.vue'\n//import Notifications from '../views/Notifications.vue'\n\n\n\nfunction lazyLoad(view) {\n  return function () {\n    return __webpack_require__(\"./views lazy recursive ^\\\\.\\\\/.*\\\\.vue$\")(\"./\".concat(view, \".vue\"));\n  };\n}\n\nvar routes = [{\n  path: '/',\n  name: 'Home',\n  component: lazyLoad(\"Home\"),\n  beforeEnter: function beforeEnter() {\n    _store_store_js__WEBPACK_IMPORTED_MODULE_7__[\"default\"].state.modalConfirm = false;\n  }\n}, {\n  path: '/profile',\n  name: 'Profile',\n  component: lazyLoad(\"Profile\")\n}, {\n  path: '/notifications',\n  name: 'Notifications',\n  component: lazyLoad(\"Notifications\")\n}, {\n  path: '/features',\n  name: 'Features',\n  component: _views_Features_vue__WEBPACK_IMPORTED_MODULE_9__[\"default\"]\n}, {\n  path: '/addQuiz',\n  name: 'AddQuiz',\n  component: _views_quizes_AddQuiz_vue__WEBPACK_IMPORTED_MODULE_4__[\"default\"]\n}, {\n  path: '/quizes/:slug/',\n  name: 'QuizDetails',\n  component: _views_quizes_QuizDetails_vue__WEBPACK_IMPORTED_MODULE_6__[\"default\"],\n  beforeEnter: function beforeEnter(to, from, next) {\n    if (_store_store_js__WEBPACK_IMPORTED_MODULE_7__[\"default\"].state.modalConfirm == false) {\n      next('/');\n    } else {\n      next();\n      _store_store_js__WEBPACK_IMPORTED_MODULE_7__[\"default\"].state.modalConfirm = true;\n    }\n  }\n}, {\n  path: '/account/',\n  name: 'account',\n  component: _views_accounts_login_vue__WEBPACK_IMPORTED_MODULE_8__[\"default\"],\n  beforeEnter: function beforeEnter(to, from, next) {\n    if (_store_store_js__WEBPACK_IMPORTED_MODULE_7__[\"default\"].state.authenticated === false) next(\"/login/\");else next();\n  }\n}, {\n  path: '/login/',\n  name: 'login',\n  component: _views_accounts_login_vue__WEBPACK_IMPORTED_MODULE_8__[\"default\"]\n}, // catchOuut\n{\n  path: '/:catchAll(.*)',\n  name: 'NotFound',\n  component: _views_NotFound_vue__WEBPACK_IMPORTED_MODULE_5__[\"default\"]\n}];\nvar router = Object(vue_router__WEBPACK_IMPORTED_MODULE_3__[\"createRouter\"])({\n  history: Object(vue_router__WEBPACK_IMPORTED_MODULE_3__[\"createWebHistory\"])(\"/quizgame\"),\n  linkExactActiveClass: 'is-active',\n  routes: routes\n});\nrouter.beforeEach(function (to, from) {\n  console.log(\"to: \" + to.fullPath + \" from: \" + from.fullPath + \" lastHistory: \" + router.back);\n});\n/* harmony default export */ __webpack_exports__[\"default\"] = (router);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yb3V0ZXIvaW5kZXguanMuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9yb3V0ZXIvaW5kZXguanM/NTFhMCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVSb3V0ZXIsIGNyZWF0ZVdlYkhpc3RvcnkgfSBmcm9tICd2dWUtcm91dGVyJ1xuLy9pbXBvcnQgSG9tZSBmcm9tICcuLi92aWV3cy9Ib21lLnZ1ZSdcbmltcG9ydCBBZGRRdWl6IGZyb20gJy4uL3ZpZXdzL3F1aXplcy9BZGRRdWl6LnZ1ZSdcbmltcG9ydCBOb3RGb3VuZCBmcm9tICcuLi92aWV3cy9Ob3RGb3VuZC52dWUnXG5pbXBvcnQgUXVpekRldGFpbHMgZnJvbSAnLi4vdmlld3MvcXVpemVzL1F1aXpEZXRhaWxzLnZ1ZSdcbmltcG9ydCBzdG9yZSBmcm9tICcuLi9zdG9yZS9zdG9yZS5qcydcbmltcG9ydCBMb2dpbiBmcm9tICcuLi92aWV3cy9hY2NvdW50cy9sb2dpbi52dWUnXG4vL2ltcG9ydCBQcm9maWxlIGZyb20gJy4uL3ZpZXdzL2FjY291bnRzL1Byb2ZpbGUudnVlJ1xuLy9pbXBvcnQgTm90aWZpY2F0aW9ucyBmcm9tICcuLi92aWV3cy9Ob3RpZmljYXRpb25zLnZ1ZSdcbmltcG9ydCBGZWF0dXJlcyBmcm9tICcuLi92aWV3cy9GZWF0dXJlcy52dWUnXG5cbmZ1bmN0aW9uIGxhenlMb2FkKHZpZXcpe1xuICByZXR1cm4oKSA9PiBpbXBvcnQoYC4uL3ZpZXdzLyR7dmlld30udnVlYClcbn1cblxuY29uc3Qgcm91dGVzID0gW1xuICB7XG4gICAgcGF0aDogJy8nLFxuICAgIG5hbWU6ICdIb21lJyxcbiAgICBjb21wb25lbnQ6IGxhenlMb2FkKFwiSG9tZVwiKSxcbiAgICBiZWZvcmVFbnRlcjogKCkgPT4ge1xuICAgICAgc3RvcmUuc3RhdGUubW9kYWxDb25maXJtID0gZmFsc2VcbiAgICB9XG4gIH0sXG4gIHtcbiAgICBwYXRoOiAnL3Byb2ZpbGUnLFxuICAgIG5hbWU6ICdQcm9maWxlJyxcbiAgICBjb21wb25lbnQ6IGxhenlMb2FkKFwiUHJvZmlsZVwiKVxuICB9LFxuICB7XG4gICAgcGF0aDogJy9ub3RpZmljYXRpb25zJyxcbiAgICBuYW1lOiAnTm90aWZpY2F0aW9ucycsXG4gICAgY29tcG9uZW50OiBsYXp5TG9hZChcIk5vdGlmaWNhdGlvbnNcIilcbiAgfSxcbiAge1xuICAgIHBhdGg6ICcvZmVhdHVyZXMnLFxuICAgIG5hbWU6ICdGZWF0dXJlcycsXG4gICAgY29tcG9uZW50OiBGZWF0dXJlcyxcbiAgfSxcbiAge1xuICAgIHBhdGg6ICcvYWRkUXVpeicsXG4gICAgbmFtZTogJ0FkZFF1aXonLFxuICAgIGNvbXBvbmVudDogQWRkUXVpelxuICB9LFxuICB7XG4gICAgcGF0aDogJy9xdWl6ZXMvOnNsdWcvJyxcbiAgICBuYW1lOiAnUXVpekRldGFpbHMnLFxuICAgIGNvbXBvbmVudDogUXVpekRldGFpbHMsXG4gICAgYmVmb3JlRW50ZXI6ICh0bywgZnJvbSwgbmV4dCkgPT4ge1xuICAgICAgXG4gICAgICBpZihzdG9yZS5zdGF0ZS5tb2RhbENvbmZpcm0gPT0gZmFsc2UpIHtcbiAgICAgICAgbmV4dCgnLycpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbmV4dCgpXG4gICAgICAgICAgc3RvcmUuc3RhdGUubW9kYWxDb25maXJtID0gdHJ1ZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBcbiAgXG4gIH0sXG4gIHtcbiAgICBwYXRoOiAnL2FjY291bnQvJyxcbiAgICBuYW1lOiAnYWNjb3VudCcsXG4gICAgY29tcG9uZW50OiBMb2dpbixcbiAgICBiZWZvcmVFbnRlcjogKHRvLCBmcm9tLCBuZXh0KSA9PiB7XG4gICAgICBpZihzdG9yZS5zdGF0ZS5hdXRoZW50aWNhdGVkID09PSBmYWxzZSkgbmV4dChcIi9sb2dpbi9cIilcbiAgICAgIGVsc2UgbmV4dCgpXG4gICAgfVxuICB9LFxuICB7XG4gICAgICBwYXRoOiAnL2xvZ2luLycsXG4gICAgICBuYW1lOiAnbG9naW4nLFxuICAgICAgY29tcG9uZW50OiBMb2dpbixcbiAgICB9LFxuICAvLyBjYXRjaE91dXRcbiAge1xuICAgIHBhdGg6ICcvOmNhdGNoQWxsKC4qKScsXG4gICAgbmFtZTogJ05vdEZvdW5kJyxcbiAgICBjb21wb25lbnQ6IE5vdEZvdW5kLFxuICB9LFxuXVxuXG5jb25zdCByb3V0ZXIgPSBjcmVhdGVSb3V0ZXIoe1xuICBoaXN0b3J5OiBjcmVhdGVXZWJIaXN0b3J5KFwiL3F1aXpnYW1lXCIpLFxuICBsaW5rRXhhY3RBY3RpdmVDbGFzczogJ2lzLWFjdGl2ZScsXG4gIHJvdXRlc1xufSlcblxucm91dGVyLmJlZm9yZUVhY2goKHRvLCBmcm9tKSA9PiB7XG4gIGNvbnNvbGUubG9nKFwidG86IFwiKyB0by5mdWxsUGF0aCArIFwiIGZyb206IFwiICsgZnJvbS5mdWxsUGF0aCArIFwiIGxhc3RIaXN0b3J5OiBcIiArIHJvdXRlci5iYWNrKVxuXG5cbn0pXG5cbmV4cG9ydCBkZWZhdWx0IHJvdXRlclxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBU0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWkE7QUFpQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBUEE7QUFVQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFPQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTtBQUdBO0FBRUEiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./router/index.js\n");

/***/ }),

/***/ "./views lazy recursive ^\\.\\/.*\\.vue$":
/*!***************************************************!*\
  !*** ./views lazy ^\.\/.*\.vue$ namespace object ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var map = {\n\t\"./About.vue\": [\n\t\t\"./views/About.vue\",\n\t\t1\n\t],\n\t\"./Features.vue\": [\n\t\t\"./views/Features.vue\"\n\t],\n\t\"./Home.vue\": [\n\t\t\"./views/Home.vue\",\n\t\t11\n\t],\n\t\"./NotFound.vue\": [\n\t\t\"./views/NotFound.vue\"\n\t],\n\t\"./Notifications.vue\": [\n\t\t\"./views/Notifications.vue\",\n\t\t13\n\t],\n\t\"./accounts/Friends.vue\": [\n\t\t\"./views/accounts/Friends.vue\",\n\t\t2\n\t],\n\t\"./accounts/Profile.vue\": [\n\t\t\"./views/accounts/Profile.vue\",\n\t\t14\n\t],\n\t\"./accounts/Rankings.vue\": [\n\t\t\"./views/accounts/Rankings.vue\",\n\t\t3\n\t],\n\t\"./accounts/Settings.vue\": [\n\t\t\"./views/accounts/Settings.vue\",\n\t\t4\n\t],\n\t\"./accounts/Wallet.vue\": [\n\t\t\"./views/accounts/Wallet.vue\",\n\t\t5\n\t],\n\t\"./accounts/login.vue\": [\n\t\t\"./views/accounts/login.vue\"\n\t],\n\t\"./other/Regulamin.vue\": [\n\t\t\"./views/other/Regulamin.vue\",\n\t\t6\n\t],\n\t\"./play_board/Duet.vue\": [\n\t\t\"./views/play_board/Duet.vue\",\n\t\t7\n\t],\n\t\"./play_board/Solo.vue\": [\n\t\t\"./views/play_board/Solo.vue\",\n\t\t8\n\t],\n\t\"./play_board/Tournament.vue\": [\n\t\t\"./views/play_board/Tournament.vue\",\n\t\t9\n\t],\n\t\"./quizes/AddQuiz.vue\": [\n\t\t\"./views/quizes/AddQuiz.vue\"\n\t],\n\t\"./quizes/Lobby.vue\": [\n\t\t\"./views/quizes/Lobby.vue\",\n\t\t10\n\t],\n\t\"./quizes/QuizDetails.vue\": [\n\t\t\"./views/quizes/QuizDetails.vue\"\n\t],\n\t\"./quizes/Quizes.vue\": [\n\t\t\"./views/quizes/Quizes.vue\",\n\t\t12\n\t],\n\t\"./quizes/QuizesV2.vue\": [\n\t\t\"./views/quizes/QuizesV2.vue\",\n\t\t0\n\t]\n};\nfunction webpackAsyncContext(req) {\n\tif(!__webpack_require__.o(map, req)) {\n\t\treturn Promise.resolve().then(function() {\n\t\t\tvar e = new Error(\"Cannot find module '\" + req + \"'\");\n\t\t\te.code = 'MODULE_NOT_FOUND';\n\t\t\tthrow e;\n\t\t});\n\t}\n\n\tvar ids = map[req], id = ids[0];\n\treturn Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {\n\t\treturn __webpack_require__(id);\n\t});\n}\nwebpackAsyncContext.keys = function webpackAsyncContextKeys() {\n\treturn Object.keys(map);\n};\nwebpackAsyncContext.id = \"./views lazy recursive ^\\\\.\\\\/.*\\\\.vue$\";\nmodule.exports = webpackAsyncContext;//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi92aWV3cyBsYXp5IHJlY3Vyc2l2ZSBeXFwuXFwvLipcXC52dWUkLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vdmlld3MgbGF6eSBeXFwuXFwvLipcXC52dWUkIG5hbWVzcGFjZSBvYmplY3Q/ZmViOCJdLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgbWFwID0ge1xuXHRcIi4vQWJvdXQudnVlXCI6IFtcblx0XHRcIi4vdmlld3MvQWJvdXQudnVlXCIsXG5cdFx0MVxuXHRdLFxuXHRcIi4vRmVhdHVyZXMudnVlXCI6IFtcblx0XHRcIi4vdmlld3MvRmVhdHVyZXMudnVlXCJcblx0XSxcblx0XCIuL0hvbWUudnVlXCI6IFtcblx0XHRcIi4vdmlld3MvSG9tZS52dWVcIixcblx0XHQxMVxuXHRdLFxuXHRcIi4vTm90Rm91bmQudnVlXCI6IFtcblx0XHRcIi4vdmlld3MvTm90Rm91bmQudnVlXCJcblx0XSxcblx0XCIuL05vdGlmaWNhdGlvbnMudnVlXCI6IFtcblx0XHRcIi4vdmlld3MvTm90aWZpY2F0aW9ucy52dWVcIixcblx0XHQxM1xuXHRdLFxuXHRcIi4vYWNjb3VudHMvRnJpZW5kcy52dWVcIjogW1xuXHRcdFwiLi92aWV3cy9hY2NvdW50cy9GcmllbmRzLnZ1ZVwiLFxuXHRcdDJcblx0XSxcblx0XCIuL2FjY291bnRzL1Byb2ZpbGUudnVlXCI6IFtcblx0XHRcIi4vdmlld3MvYWNjb3VudHMvUHJvZmlsZS52dWVcIixcblx0XHQxNFxuXHRdLFxuXHRcIi4vYWNjb3VudHMvUmFua2luZ3MudnVlXCI6IFtcblx0XHRcIi4vdmlld3MvYWNjb3VudHMvUmFua2luZ3MudnVlXCIsXG5cdFx0M1xuXHRdLFxuXHRcIi4vYWNjb3VudHMvU2V0dGluZ3MudnVlXCI6IFtcblx0XHRcIi4vdmlld3MvYWNjb3VudHMvU2V0dGluZ3MudnVlXCIsXG5cdFx0NFxuXHRdLFxuXHRcIi4vYWNjb3VudHMvV2FsbGV0LnZ1ZVwiOiBbXG5cdFx0XCIuL3ZpZXdzL2FjY291bnRzL1dhbGxldC52dWVcIixcblx0XHQ1XG5cdF0sXG5cdFwiLi9hY2NvdW50cy9sb2dpbi52dWVcIjogW1xuXHRcdFwiLi92aWV3cy9hY2NvdW50cy9sb2dpbi52dWVcIlxuXHRdLFxuXHRcIi4vb3RoZXIvUmVndWxhbWluLnZ1ZVwiOiBbXG5cdFx0XCIuL3ZpZXdzL290aGVyL1JlZ3VsYW1pbi52dWVcIixcblx0XHQ2XG5cdF0sXG5cdFwiLi9wbGF5X2JvYXJkL0R1ZXQudnVlXCI6IFtcblx0XHRcIi4vdmlld3MvcGxheV9ib2FyZC9EdWV0LnZ1ZVwiLFxuXHRcdDdcblx0XSxcblx0XCIuL3BsYXlfYm9hcmQvU29sby52dWVcIjogW1xuXHRcdFwiLi92aWV3cy9wbGF5X2JvYXJkL1NvbG8udnVlXCIsXG5cdFx0OFxuXHRdLFxuXHRcIi4vcGxheV9ib2FyZC9Ub3VybmFtZW50LnZ1ZVwiOiBbXG5cdFx0XCIuL3ZpZXdzL3BsYXlfYm9hcmQvVG91cm5hbWVudC52dWVcIixcblx0XHQ5XG5cdF0sXG5cdFwiLi9xdWl6ZXMvQWRkUXVpei52dWVcIjogW1xuXHRcdFwiLi92aWV3cy9xdWl6ZXMvQWRkUXVpei52dWVcIlxuXHRdLFxuXHRcIi4vcXVpemVzL0xvYmJ5LnZ1ZVwiOiBbXG5cdFx0XCIuL3ZpZXdzL3F1aXplcy9Mb2JieS52dWVcIixcblx0XHQxMFxuXHRdLFxuXHRcIi4vcXVpemVzL1F1aXpEZXRhaWxzLnZ1ZVwiOiBbXG5cdFx0XCIuL3ZpZXdzL3F1aXplcy9RdWl6RGV0YWlscy52dWVcIlxuXHRdLFxuXHRcIi4vcXVpemVzL1F1aXplcy52dWVcIjogW1xuXHRcdFwiLi92aWV3cy9xdWl6ZXMvUXVpemVzLnZ1ZVwiLFxuXHRcdDEyXG5cdF0sXG5cdFwiLi9xdWl6ZXMvUXVpemVzVjIudnVlXCI6IFtcblx0XHRcIi4vdmlld3MvcXVpemVzL1F1aXplc1YyLnZ1ZVwiLFxuXHRcdDBcblx0XVxufTtcbmZ1bmN0aW9uIHdlYnBhY2tBc3luY0NvbnRleHQocmVxKSB7XG5cdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8obWFwLCByZXEpKSB7XG5cdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oZnVuY3Rpb24oKSB7XG5cdFx0XHR2YXIgZSA9IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIgKyByZXEgKyBcIidcIik7XG5cdFx0XHRlLmNvZGUgPSAnTU9EVUxFX05PVF9GT1VORCc7XG5cdFx0XHR0aHJvdyBlO1xuXHRcdH0pO1xuXHR9XG5cblx0dmFyIGlkcyA9IG1hcFtyZXFdLCBpZCA9IGlkc1swXTtcblx0cmV0dXJuIFByb21pc2UuYWxsKGlkcy5zbGljZSgxKS5tYXAoX193ZWJwYWNrX3JlcXVpcmVfXy5lKSkudGhlbihmdW5jdGlvbigpIHtcblx0XHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhpZCk7XG5cdH0pO1xufVxud2VicGFja0FzeW5jQ29udGV4dC5rZXlzID0gZnVuY3Rpb24gd2VicGFja0FzeW5jQ29udGV4dEtleXMoKSB7XG5cdHJldHVybiBPYmplY3Qua2V5cyhtYXApO1xufTtcbndlYnBhY2tBc3luY0NvbnRleHQuaWQgPSBcIi4vdmlld3MgbGF6eSByZWN1cnNpdmUgXlxcXFwuXFxcXC8uKlxcXFwudnVlJFwiO1xubW9kdWxlLmV4cG9ydHMgPSB3ZWJwYWNrQXN5bmNDb250ZXh0OyJdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./views lazy recursive ^\\.\\/.*\\.vue$\n");

/***/ }),

/***/ "./views/Home.vue":
false,

/***/ "./views/Home.vue?vue&type=script&lang=js":
false,

/***/ "./views/Home.vue?vue&type=template&id=2f2be7e4":
false,

/***/ "./views/Notifications.vue":
false,

/***/ "./views/Notifications.vue?vue&type=script&lang=js":
false,

/***/ "./views/Notifications.vue?vue&type=template&id=cf555d6e":
false,

/***/ "./views/accounts/Profile.vue":
false,

/***/ "./views/accounts/Profile.vue?vue&type=script&lang=js":
false,

/***/ "./views/accounts/Profile.vue?vue&type=template&id=03d2b722":
false,

/***/ "./views/quizes/Quizes.vue":
false,

/***/ "./views/quizes/Quizes.vue?vue&type=script&lang=js":
false,

/***/ "./views/quizes/Quizes.vue?vue&type=style&index=0&id=9b13c6a0&lang=css":
false,

/***/ "./views/quizes/Quizes.vue?vue&type=template&id=9b13c6a0":
false

})