webpackHotUpdate(2,{

/***/ "./node_modules/core-js/internals/advance-string-index.js":
false,

/***/ "./node_modules/core-js/internals/get-substitution.js":
false,

/***/ "./node_modules/core-js/modules/es.string.replace.js":
false

})