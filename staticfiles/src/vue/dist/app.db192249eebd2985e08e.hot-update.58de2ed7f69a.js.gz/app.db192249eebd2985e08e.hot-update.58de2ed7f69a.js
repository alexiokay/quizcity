webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/App.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader-v16/dist??ref--1-1!./src/App.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _components_Navbar_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/Navbar.vue */ \"./src/components/Navbar.vue\");\n/* harmony import */ var _components_Navbar_vue__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_components_Navbar_vue__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_SideBar_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/SideBar.vue */ \"./src/components/SideBar.vue\");\n/* harmony import */ var _components_Footer_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/Footer.vue */ \"./src/components/Footer.vue\");\n\n\n\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  name: 'App',\n  components: {\n    Navbar: _components_Navbar_vue__WEBPACK_IMPORTED_MODULE_0___default.a,\n    SideBar: _components_SideBar_vue__WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n    Footer: _components_Footer_vue__WEBPACK_IMPORTED_MODULE_2__[\"default\"]\n  },\n  mounted: function mounted() {\n    console.log(\"http://localhost:8002/\" + \"api/quizes/\");\n  }\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvY2FjaGUtbG9hZGVyL2Rpc3QvY2pzLmpzPyEuL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4vbm9kZV9tb2R1bGVzL2NhY2hlLWxvYWRlci9kaXN0L2Nqcy5qcz8hLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci12MTYvZGlzdC9pbmRleC5qcz8hLi9zcmMvQXBwLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3NyYy9BcHAudnVlPzNkZmQiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxuICA8U3VzcGVuc2U+XG4gICAgPHRlbXBsYXRlICNkZWZhdWx0PlxuICAgICAgPGRpdiBjbGFzcz1cImFwcFwiPlxuICAgICAgICA8TmF2YmFyIHYtaWY9XCIkcm91dGUubWV0YS5uYXZiYXJPblwiPjwvTmF2YmFyPlxuICAgICAgICA8U2lkZUJhcj48L1NpZGVCYXI+XG5cbiAgICAgICAgXG4gICAgICA8bWFpbiBjbGFzcz1cIm1haW5cIj5cbiAgICAgICAgPHJvdXRlci12aWV3Pjwvcm91dGVyLXZpZXc+XG4gICAgICA8L21haW4+XG5cbiAgICAgXG4gICAgPEZvb3Rlcj48L0Zvb3Rlcj5cbiAgICAgIDwvZGl2PlxuICAgICAgXG4gICAgPC90ZW1wbGF0ZT5cblxuICAgICA8dGVtcGxhdGUgI2ZhbGxiYWNrPlxuICAgICAgIExvYWRpbmcuLlxuICAgIDwvdGVtcGxhdGU+XG4gIDwvU3VzcGVuc2U+XG4gIFxuPC90ZW1wbGF0ZT5cblxuPHNjcmlwdD5cbmltcG9ydCBOYXZiYXIgZnJvbSAnLi9jb21wb25lbnRzL05hdmJhci52dWUnXG5pbXBvcnQgU2lkZUJhciBmcm9tICcuL2NvbXBvbmVudHMvU2lkZUJhci52dWUnXG5pbXBvcnQgRm9vdGVyIGZyb20gJy4vY29tcG9uZW50cy9Gb290ZXIudnVlJ1xuXG5cblxuZXhwb3J0IGRlZmF1bHQge1xuICBuYW1lOiAnQXBwJyxcbiAgY29tcG9uZW50czoge1xuICAgIE5hdmJhcixcbiAgICBTaWRlQmFyLFxuICAgIEZvb3RlcixcblxuICB9LFxuICAgIG1vdW50ZWQoKSB7XG4gICAgY29uc29sZS5sb2cocHJvY2Vzcy5lbnYuVlVFX0FQUF9ST09UX0FQSSArIFwiYXBpL3F1aXplcy9cIilcblxuICBcblx0XG4gIH1cbn1cbjwvc2NyaXB0PlxuXG48c3R5bGUgPlxuXG4ubWFpbiB7XG5cdHRleHQtYWxpZ246IGNlbnRlcjtcblx0bWFyZ2luLWxlZnQ6IDVyZW07XG5cbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA5OTFweCkge1xuICAubWFpbiB7XG4gICAgbWFyZ2luOiAwO1xuICB9XG59XG5cbjpyb290IHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LWZhbWlseTogJ09wZW4gU2Fucyc7XG4gIC0tdGV4dC1wcmltYXJ5OiAjYjZiNmI2O1xuICAtLXRleHQtc2Vjb25kYXJ5OiAjZWNlY2VjO1xuICAtLWJnLXByaW1hcnk6ICMyMzIzMmU7XG4gIC0tYmctc2Vjb25kYXJ5OiAjMTQxNDE4O1xuICAtLWJnLXRoaXJkYXJ5OiByZ2IoNjEsIDUsIDUpO1xuICAtLXRyYW5zaXRpb24tc3BlZWQ6IDYwMG1zO1xuICBcbn1cblxuXG5idXR0b24ge1xuXHRjdXJzb3I6IHBvaW50ZXI7XG5cdGFwcGVhcmFuY2U6IG5vbmU7XG5cdGJvcmRlcjogbm9uZTtcblx0b3V0bGluZTogbm9uZTtcblx0YmFja2dyb3VuZDogbm9uZTtcbn1cblxuLmFwcCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbjwvc3R5bGU+XG5cbiJdLCJtYXBwaW5ncyI6IkFBMEJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBQ0E7QUFJQTtBQWJBIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/App.vue?vue&type=script&lang=js\n");

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/components/Navbar.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/components/Searchbar.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/components/Navbar.vue?vue&type=template&id=41458b80&scoped=true":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/components/Searchbar.vue?vue&type=template&id=a8dcc02a&scoped=true":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=template&id=adc7f09e":
false,

/***/ "./node_modules/core-js/internals/array-for-each.js":
false,

/***/ "./node_modules/core-js/internals/array-from.js":
false,

/***/ "./node_modules/core-js/internals/array-method-is-strict.js":
false,

/***/ "./node_modules/core-js/internals/call-with-safe-iteration-closing.js":
false,

/***/ "./node_modules/core-js/internals/correct-is-regexp-logic.js":
false,

/***/ "./node_modules/core-js/internals/create-property.js":
false,

/***/ "./node_modules/core-js/internals/fix-regexp-well-known-symbol-logic.js":
false,

/***/ "./node_modules/core-js/internals/is-regexp.js":
false,

/***/ "./node_modules/core-js/internals/not-a-regexp.js":
false,

/***/ "./node_modules/core-js/internals/regexp-exec-abstract.js":
false,

/***/ "./node_modules/core-js/internals/regexp-exec.js":
false,

/***/ "./node_modules/core-js/internals/regexp-sticky-helpers.js":
false,

/***/ "./node_modules/core-js/internals/regexp-unsupported-dot-all.js":
false,

/***/ "./node_modules/core-js/internals/regexp-unsupported-ncg.js":
false,

/***/ "./node_modules/core-js/internals/same-value.js":
false,

/***/ "./node_modules/core-js/modules/es.array.from.js":
false,

/***/ "./node_modules/core-js/modules/es.array.map.js":
false,

/***/ "./node_modules/core-js/modules/es.function.name.js":
false,

/***/ "./node_modules/core-js/modules/es.regexp.exec.js":
false,

/***/ "./node_modules/core-js/modules/es.string.search.js":
false,

/***/ "./node_modules/core-js/modules/es.string.starts-with.js":
false,

/***/ "./node_modules/core-js/modules/web.dom-collections.for-each.js":
false,

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/components/Navbar.vue?vue&type=style&index=0&id=41458b80&scoped=true&lang=css":
false,

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/components/Searchbar.vue?vue&type=style&index=0&id=a8dcc02a&scoped=true&lang=css":
false,

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=style&index=0&id=adc7f09e&lang=css":
false,

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/components/Navbar.vue?vue&type=style&index=0&id=41458b80&scoped=true&lang=css":
false,

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./src/components/Searchbar.vue?vue&type=style&index=0&id=a8dcc02a&scoped=true&lang=css":
false,

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=style&index=0&id=adc7f09e&lang=css":
false,

/***/ "./src/assets/expandSidebar.js":
false,

/***/ "./src/components/Navbar.vue":
/*!***********************************!*\
  !*** ./src/components/Navbar.vue ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9OYXZiYXIudnVlLmpzIiwic291cmNlcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/Navbar.vue\n");

/***/ }),

/***/ "./src/components/Navbar.vue?vue&type=script&lang=js":
false,

/***/ "./src/components/Navbar.vue?vue&type=style&index=0&id=41458b80&scoped=true&lang=css":
false,

/***/ "./src/components/Navbar.vue?vue&type=template&id=41458b80&scoped=true":
false,

/***/ "./src/components/Searchbar.vue":
false,

/***/ "./src/components/Searchbar.vue?vue&type=script&lang=js":
false,

/***/ "./src/components/Searchbar.vue?vue&type=style&index=0&id=a8dcc02a&scoped=true&lang=css":
false,

/***/ "./src/components/Searchbar.vue?vue&type=template&id=a8dcc02a&scoped=true":
false,

/***/ "./views/shop/MiniCart.vue":
false,

/***/ "./views/shop/MiniCart.vue?vue&type=script&lang=js":
false,

/***/ "./views/shop/MiniCart.vue?vue&type=style&index=0&id=adc7f09e&lang=css":
false,

/***/ "./views/shop/MiniCart.vue?vue&type=template&id=adc7f09e":
false

})