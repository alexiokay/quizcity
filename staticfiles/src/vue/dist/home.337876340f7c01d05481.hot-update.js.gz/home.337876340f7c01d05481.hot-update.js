webpackHotUpdate("home",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Home.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader-v16/dist??ref--1-1!./views/Home.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _views_quizes_Quizes_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../views/quizes/Quizes.vue */ \"./views/quizes/Quizes.vue\");\n/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue */ \"./node_modules/vue/dist/vue.esm-bundler.js\");\n// @ is an alias to /src\n\n //import MiniCart from '../views/shop/MiniCart.vue'\n\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  name: \"Home\",\n  components: {\n    QuizList: _views_quizes_Quizes_vue__WEBPACK_IMPORTED_MODULE_0__[\"default\"],\n    MiniCart: MiniCart\n  },\n  data: function data() {\n    return {\n      isVisible: true,\n      error: Object(vue__WEBPACK_IMPORTED_MODULE_1__[\"ref\"])(null)\n    };\n  },\n  setup: function setup() {\n    var _this = this;\n\n    Object(vue__WEBPACK_IMPORTED_MODULE_1__[\"onErrorCaptured\"])(function (e) {\n      _this.error.value = e;\n    });\n  },\n  methods: {\n    change: function change() {\n      this.isVisible = !this.isVisible;\n    }\n  }\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvY2FjaGUtbG9hZGVyL2Rpc3QvY2pzLmpzPyEuL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4vbm9kZV9tb2R1bGVzL2NhY2hlLWxvYWRlci9kaXN0L2Nqcy5qcz8hLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci12MTYvZGlzdC9pbmRleC5qcz8hLi92aWV3cy9Ib21lLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3ZpZXdzL0hvbWUudnVlPzkwNjAiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxuXG4gIDxkaXYgaWQ9XCJhcHBcIj5cbiAgICA8ZGl2IHYtaWY9XCJlcnJvclwiPnt7ZXJyb3J9fX08L2Rpdj5cbiAgICA8U3VzcGVuc2U+XG4gICAgICA8dGVtcGxhdGUgI2RlZmF1bHQ+XG4gICAgICA8UXVpekxpc3QgPjwvUXVpekxpc3Q+XG5cbiAgICAgIDwvdGVtcGxhdGU+XG4gICAgICA8dGVtcGxhdGUgI2ZhbGxiYWNrPmxvYWRpbmcgICBxdWl6ZXM8L3RlbXBsYXRlPlxuICAgIDwvU3VzcGVuc2U+XG4gIDwvZGl2PlxuXG4gIFxuPC90ZW1wbGF0ZT5cblxuPHNjcmlwdD5cbi8vIEAgaXMgYW4gYWxpYXMgdG8gL3NyY1xuaW1wb3J0IFF1aXpMaXN0IGZyb20gXCIuLi92aWV3cy9xdWl6ZXMvUXVpemVzLnZ1ZVwiO1xuaW1wb3J0IHtyZWYsIG9uRXJyb3JDYXB0dXJlZH0gZnJvbSAndnVlJ1xuLy9pbXBvcnQgTWluaUNhcnQgZnJvbSAnLi4vdmlld3Mvc2hvcC9NaW5pQ2FydC52dWUnXG5cblxuXG5leHBvcnQgZGVmYXVsdCB7XG4gIG5hbWU6IFwiSG9tZVwiLFxuICBjb21wb25lbnRzOiB7XG4gICAgUXVpekxpc3QsXG4gICAgTWluaUNhcnQsXG5cblxuXG4gIH0sXG4gIGRhdGEoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGlzVmlzaWJsZTogdHJ1ZSxcbiAgICAgIGVycm9yOiByZWYobnVsbCksXG4gICAgfVxuICB9LFxuICBzZXR1cCgpIHtcblxuXG4gICAgb25FcnJvckNhcHR1cmVkKCBlID0+IHtcbiAgICAgIHRoaXMuZXJyb3IudmFsdWUgPSBlXG4gICAgfSlcbiAgfSxcbiAgbWV0aG9kczoge1xuICAgIGNoYW5nZSgpIHtcbiAgICAgIHRoaXMuaXNWaXNpYmxlID0gIXRoaXMuaXNWaXNpYmxlXG4gICAgfVxuICB9LFxufTtcbjwvc2NyaXB0PlxuXG48c3R5bGUgc2NvcGVkPlxuXG5cblxuPC9zdHlsZT4iXSwibWFwcGluZ3MiOiJBQWlCQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQXRCQSIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Home.vue?vue&type=script&lang=js\n");

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/pug-plain-loader/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=template&id=adc7f09e&lang=pug":
false,

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=style&index=0&id=adc7f09e&lang=scss":
false,

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=style&index=0&id=adc7f09e&lang=scss":
false,

/***/ "./views/shop/MiniCart.vue":
false,

/***/ "./views/shop/MiniCart.vue?vue&type=script&lang=js":
false,

/***/ "./views/shop/MiniCart.vue?vue&type=style&index=0&id=adc7f09e&lang=scss":
false,

/***/ "./views/shop/MiniCart.vue?vue&type=template&id=adc7f09e&lang=pug":
false

})