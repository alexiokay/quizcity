webpackHotUpdate(6,{

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Notifications.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader-v16/dist??ref--1-1!./views/Notifications.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed (from ./node_modules/babel-loader/lib/index.js):\\nSyntaxError: C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\views\\\\Notifications.vue: Unexpected token, expected \\\",\\\" (20:2)\\n\\n\\u001b[0m \\u001b[90m 18 |\\u001b[39m   }\\u001b[0m\\n\\u001b[0m \\u001b[90m 19 |\\u001b[39m\\u001b[0m\\n\\u001b[0m\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 20 |\\u001b[39m   mounted() {\\u001b[0m\\n\\u001b[0m \\u001b[90m    |\\u001b[39m   \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 21 |\\u001b[39m     \\u001b[36mlet\\u001b[39m now \\u001b[33m=\\u001b[39m \\u001b[33mDate\\u001b[39m\\u001b[33m.\\u001b[39mnow()\\u001b[0m\\n\\u001b[0m \\u001b[90m 22 |\\u001b[39m     now\\u001b[33m=\\u001b[39m \\u001b[36mnew\\u001b[39m \\u001b[33mDate\\u001b[39m(now)\\u001b[33m.\\u001b[39mgetTime()\\u001b[0m\\n\\u001b[0m \\u001b[90m 23 |\\u001b[39m     fetch(process\\u001b[33m.\\u001b[39menv\\u001b[33m.\\u001b[39m\\u001b[33mVUE_APP_ROOT_API\\u001b[39m \\u001b[33m+\\u001b[39m \\u001b[32m`api/mygames/`\\u001b[39m)\\u001b[0m\\n    at Object._raise (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:476:17)\\n    at Object.raiseWithData (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:469:17)\\n    at Object.raise (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:430:17)\\n    at Object.unexpected (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:3789:16)\\n    at Object.expect (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:3773:28)\\n    at Object.parseObjectLike (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:13086:14)\\n    at Object.parseExprAtom (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12498:23)\\n    at Object.parseExprAtom (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:7812:20)\\n    at Object.parseExprSubscripts (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12149:23)\\n    at Object.parseUpdate (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12129:21)\\n    at Object.parseMaybeUnary (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12104:23)\\n    at Object.parseMaybeUnaryOrPrivate (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:11901:61)\\n    at Object.parseExprOps (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:11908:23)\\n    at Object.parseMaybeConditional (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:11878:23)\\n    at Object.parseMaybeAssign (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:11833:21)\\n    at C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:11791:39\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvY2FjaGUtbG9hZGVyL2Rpc3QvY2pzLmpzPyEuL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4vbm9kZV9tb2R1bGVzL2NhY2hlLWxvYWRlci9kaXN0L2Nqcy5qcz8hLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci12MTYvZGlzdC9pbmRleC5qcz8hLi92aWV3cy9Ob3RpZmljYXRpb25zLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcy5qcyIsInNvdXJjZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Notifications.vue?vue&type=script&lang=js\n");

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Notifications.vue?vue&type=template&id=cf555d6e":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader-v16/dist/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader-v16/dist??ref--1-1!./views/Notifications.vue?vue&type=template&id=cf555d6e ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"render\", function() { return render; });\n/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ \"./node_modules/vue/dist/vue.esm-bundler.js\");\n\n\nvar _hoisted_1 = /*#__PURE__*/Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementVNode\"])(\"h1\", null, \"this is notifications page\", -1\n/* HOISTED */\n);\n\nvar _hoisted_2 = /*#__PURE__*/Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementVNode\"])(\"hr\", null, null, -1\n/* HOISTED */\n);\n\nfunction render(_ctx, _cache) {\n  return Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"openBlock\"])(), Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementBlock\"])(\"div\", null, [_hoisted_1, (Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"openBlock\"])(true), Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementBlock\"])(vue__WEBPACK_IMPORTED_MODULE_0__[\"Fragment\"], null, Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"renderList\"])(_ctx.notifications, function (notification) {\n    return Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"openBlock\"])(), Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementBlock\"])(\"div\", {\n      key: notification.id,\n      class: \"div\"\n    }, [Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementVNode\"])(\"div\", null, [Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementVNode\"])(\"h4\", null, \"Quiz Name: \" + Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"toDisplayString\"])(notification.quiz), 1\n    /* TEXT */\n    ), Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementVNode\"])(\"h4\", null, \"sender: \" + Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"toDisplayString\"])(notification.quiz), 1\n    /* TEXT */\n    ), Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createTextVNode\"])(\" \" + Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"toDisplayString\"])(notification.created_at = new Date(notification.created_at).getTime()) + \" \", 1\n    /* TEXT */\n    ), Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementVNode\"])(\"button\", {\n      onClick: _cache[0] || (_cache[0] = function () {\n        return _ctx.play && _ctx.play.apply(_ctx, arguments);\n      }),\n      class: \"btn btn-primary\"\n    }, \"play\")]), _hoisted_2]);\n  }), 128\n  /* KEYED_FRAGMENT */\n  ))]);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvY2FjaGUtbG9hZGVyL2Rpc3QvY2pzLmpzPyEuL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXItdjE2L2Rpc3QvdGVtcGxhdGVMb2FkZXIuanM/IS4vbm9kZV9tb2R1bGVzL2NhY2hlLWxvYWRlci9kaXN0L2Nqcy5qcz8hLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci12MTYvZGlzdC9pbmRleC5qcz8hLi92aWV3cy9Ob3RpZmljYXRpb25zLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD1jZjU1NWQ2ZS5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3ZpZXdzL05vdGlmaWNhdGlvbnMudnVlP2NhNTYiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxyXG4gIDxkaXY+XHJcbiAgICA8aDE+dGhpcyBpcyBub3RpZmljYXRpb25zIHBhZ2U8L2gxPlxyXG4gICAgPGRpdlxyXG4gICAgICB2LWZvcj1cIm5vdGlmaWNhdGlvbiBpbiBub3RpZmljYXRpb25zXCJcclxuICAgICAgOmtleT1cIm5vdGlmaWNhdGlvbi5pZFwiXHJcbiAgICAgIGNsYXNzPVwiZGl2XCJcclxuICAgID5cclxuICAgICAgPGRpdiA+XHJcbiAgICAgICAgPGg0PlF1aXogTmFtZToge3tub3RpZmljYXRpb24ucXVpen19PC9oND5cclxuICAgICAgICA8aDQ+c2VuZGVyOiB7e25vdGlmaWNhdGlvbi5xdWl6fX08L2g0PlxyXG4gICAgICAgIHt7bm90aWZpY2F0aW9uLmNyZWF0ZWRfYXQgPSBuZXcgRGF0ZShub3RpZmljYXRpb24uY3JlYXRlZF9hdCkuZ2V0VGltZSgpfX1cclxuICAgICAgICA8YnV0dG9uIEBjbGljaz1cInBsYXlcIiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeVwiPnBsYXk8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxocj5cclxuICAgIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG48L3RlbXBsYXRlPlxyXG5cclxuPHNjcmlwdD5cclxuZXhwb3J0IGRlZmF1bHQge1xyXG4gIG5hbWU6IFwiTm90aWZpY2F0aW9uc1wiLFxyXG4gIGRhdGEoKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBub3RpZmljYXRpb25zOiBbXSxcclxuICAgIH07XHJcbiAgfSxcclxuICBtZXRob2RzOiB7XHJcbiAgICBsb2FkT3BwcG9uZW50KCkge1xyXG4gICAgICAvLyBDcmVhdGUgRGphbmdvIENoYW5uZWxzIG9yIHNvY2tldC5pbyBvciB3ZWJzb2NrZXRzIHJvb21cclxuICAgICAgLy8gc2VudCBvcHBvbmVudCBkYXRhIGZyb20gYXBwIHRvIHNvY2tldCByb29tXHJcbiAgICAgIC8vIGxvYWQgZGF0YSBoZXJlIGFuZCB1bnBhY2sgaXRcclxuICAgICAgLy8gc2F2ZSBkYXRhIHRvIHBsYXllcnNbMV1cclxuICAgICAgY29uc29sZS5sb2codGhpcy5xdWl6Wyd0aXRsZSddKVxyXG4gICAgICB0aGlzLiRyb3V0ZXIucHVzaCh7IG5hbWU6ICdGcmllbmRzJywgcGFyYW1zOiB7cXVpel90b19pbnZpdGVfbmFtZTogdGhpcy5xdWl6Wyd0aXRsZSddLCBxdWl6X3RvX2ludml0ZV9pZDogdGhpcy5xdWl6WydpZCddfX0pXHJcbiAgICB9LFxyXG4gIH1cclxuXHJcbiAgbW91bnRlZCgpIHtcclxuICAgIGxldCBub3cgPSBEYXRlLm5vdygpXHJcbiAgICBub3c9IG5ldyBEYXRlKG5vdykuZ2V0VGltZSgpXHJcbiAgICBmZXRjaChwcm9jZXNzLmVudi5WVUVfQVBQX1JPT1RfQVBJICsgYGFwaS9teWdhbWVzL2ApXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHJlcy5qc29uKCkpXHJcbiAgICAgIC50aGVuKGRhdGEgPT4ge1xyXG4gICAgICAgIGZvciAobGV0IG9iIG9mIGRhdGEpIHtcclxuICAgICAgICAgIGxldCBjcmVhdGVkID0gb2IuY3JlYXRlZF9hdDtcclxuICAgICAgICAgIGNyZWF0ZWQgPSBuZXcgRGF0ZShjcmVhdGVkKS5nZXRUaW1lKClcclxuICAgICAgICAgIC8vIGlmIGdhbWUgaXMgb2xkZXIgdGhhbiAxNSBtaW51dGVzIC0+IGlnbm9yZVxyXG4gICAgICAgICAgaWYgKG5vdyAtIGNyZWF0ZWQgPCA5MDAwMDAgJiYgb2IuaXNfb3ZlciA9PT0gZmFsc2UpIHRoaXMubm90aWZpY2F0aW9ucy5wdXNoKG9iKVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IGNvbnNvbGUubG9nKGVyci5tZXNzYWdlKSk7XHJcbiAgfSwgIFxyXG59O1xyXG48L3NjcmlwdD5cclxuXHJcbjxzdHlsZT48L3N0eWxlPlxyXG4iXSwibWFwcGluZ3MiOiI7Ozs7O0FBRUE7QUFBQTtBQUFBO0FBQ0E7QUFXQTtBQUFBO0FBQUE7QUFDQTs7QUFkQTtBQUVBO0FBRUE7QUFDQTtBQVNBO0FBTkE7QUFBQTtBQUNBO0FBQUE7QUFFQTtBQUNBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUdBOztBQVpBO0EiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Notifications.vue?vue&type=template&id=cf555d6e\n");

/***/ }),

/***/ "./node_modules/core-js/internals/array-slice-simple.js":
false,

/***/ "./node_modules/core-js/internals/clear-error-stack.js":
false,

/***/ "./node_modules/core-js/internals/define-well-known-symbol.js":
false,

/***/ "./node_modules/core-js/internals/error-stack-installable.js":
false,

/***/ "./node_modules/core-js/internals/inherit-if-required.js":
false,

/***/ "./node_modules/core-js/internals/install-error-cause.js":
false,

/***/ "./node_modules/core-js/internals/normalize-string-argument.js":
false,

/***/ "./node_modules/core-js/internals/object-get-own-property-names-external.js":
false,

/***/ "./node_modules/core-js/internals/path.js":
false,

/***/ "./node_modules/core-js/internals/well-known-symbol-wrapped.js":
false,

/***/ "./node_modules/core-js/internals/wrap-error-constructor-with-cause.js":
false,

/***/ "./node_modules/core-js/modules/es.array.slice.js":
false,

/***/ "./node_modules/core-js/modules/es.error.cause.js":
false,

/***/ "./node_modules/core-js/modules/es.regexp.test.js":
false,

/***/ "./node_modules/core-js/modules/es.symbol.description.js":
false,

/***/ "./node_modules/core-js/modules/es.symbol.iterator.js":
false,

/***/ "./node_modules/core-js/modules/es.symbol.js":
false

})