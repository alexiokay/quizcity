webpackHotUpdate("home",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Home.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader-v16/dist??ref--1-1!./views/Home.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed (from ./node_modules/babel-loader/lib/index.js):\\nSyntaxError: C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\views\\\\Home.vue: Unexpected token, expected \\\",\\\" (22:25)\\n\\n\\u001b[0m \\u001b[90m 20 |\\u001b[39m       isVisible\\u001b[33m:\\u001b[39m \\u001b[36mtrue\\u001b[39m\\u001b[33m,\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 21 |\\u001b[39m       error\\u001b[33m:\\u001b[39m ref(\\u001b[36mnull\\u001b[39m)\\u001b[33m,\\u001b[39m\\u001b[0m\\n\\u001b[0m\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 22 |\\u001b[39m       is_cart_open\\u001b[33m:\\u001b[39m \\u001b[36mfalse\\u001b[39m\\u001b[33m;\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m    |\\u001b[39m                          \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 23 |\\u001b[39m     }\\u001b[0m\\n\\u001b[0m \\u001b[90m 24 |\\u001b[39m   }\\u001b[33m,\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 25 |\\u001b[39m   setup() {\\u001b[0m\\n    at instantiate (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:72:32)\\n    at constructor (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:358:12)\\n    at Object.raise (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:3336:19)\\n    at Object.unexpected (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:3374:16)\\n    at Object.expect (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:4003:28)\\n    at Object.parseObjectLike (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:13592:14)\\n    at Object.parseExprAtom (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12995:23)\\n    at Object.parseExprAtom (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:8036:20)\\n    at Object.parseExprSubscripts (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12645:23)\\n    at Object.parseUpdate (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12624:21)\\n    at Object.parseMaybeUnary (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12595:23)\\n    at Object.parseMaybeUnaryOrPrivate (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12389:61)\\n    at Object.parseExprOps (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12396:23)\\n    at Object.parseMaybeConditional (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12366:23)\\n    at Object.parseMaybeAssign (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12318:21)\\n    at Object.parseExpressionBase (C:\\\\Users\\\\papad\\\\OneDrive\\\\Dokumenty\\\\MEGA\\\\MEGAsync\\\\AppDev\\\\10.02.22\\\\quizCityDeployed\\\\blog\\\\frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12254:23)\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvY2FjaGUtbG9hZGVyL2Rpc3QvY2pzLmpzPyEuL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4vbm9kZV9tb2R1bGVzL2NhY2hlLWxvYWRlci9kaXN0L2Nqcy5qcz8hLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci12MTYvZGlzdC9pbmRleC5qcz8hLi92aWV3cy9Ib21lLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcy5qcyIsInNvdXJjZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Home.vue?vue&type=script&lang=js\n");

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/Quizes.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Home.vue?vue&type=template&id=2f2be7e4":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader-v16/dist/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader-v16/dist??ref--1-1!./views/Home.vue?vue&type=template&id=2f2be7e4 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"render\", function() { return render; });\n/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ \"./node_modules/vue/dist/vue.esm-bundler.js\");\n\nvar _hoisted_1 = {\n  id: \"app\"\n};\nvar _hoisted_2 = {\n  key: 0\n};\n\nvar _hoisted_3 = /*#__PURE__*/Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createTextVNode\"])(\"loading quizes\");\n\nfunction render(_ctx, _cache) {\n  var _component_QuizList = Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"resolveComponent\"])(\"QuizList\");\n\n  var _component_MiniCart = Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"resolveComponent\"])(\"MiniCart\");\n\n  return Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"openBlock\"])(), Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementBlock\"])(vue__WEBPACK_IMPORTED_MODULE_0__[\"Fragment\"], null, [Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementVNode\"])(\"div\", _hoisted_1, [_ctx.error ? (Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"openBlock\"])(), Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createElementBlock\"])(\"div\", _hoisted_2, Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"toDisplayString\"])(_ctx.error) + \"}\", 1\n  /* TEXT */\n  )) : Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createCommentVNode\"])(\"v-if\", true), (Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"openBlock\"])(), Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createBlock\"])(vue__WEBPACK_IMPORTED_MODULE_0__[\"Suspense\"], null, {\n    default: Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"withCtx\"])(function () {\n      return [Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createVNode\"])(_component_QuizList)];\n    }),\n    fallback: Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"withCtx\"])(function () {\n      return [_hoisted_3];\n    }),\n    _: 1\n    /* STABLE */\n\n  }))]), _ctx.is_cart_open ? (Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"openBlock\"])(), Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createBlock\"])(_component_MiniCart, {\n    key: 0\n  })) : Object(vue__WEBPACK_IMPORTED_MODULE_0__[\"createCommentVNode\"])(\"v-if\", true)], 64\n  /* STABLE_FRAGMENT */\n  );\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvY2FjaGUtbG9hZGVyL2Rpc3QvY2pzLmpzPyEuL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXItdjE2L2Rpc3QvdGVtcGxhdGVMb2FkZXIuanM/IS4vbm9kZV9tb2R1bGVzL2NhY2hlLWxvYWRlci9kaXN0L2Nqcy5qcz8hLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci12MTYvZGlzdC9pbmRleC5qcz8hLi92aWV3cy9Ib21lLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0yZjJiZTdlNC5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3ZpZXdzL0hvbWUudnVlPzkwNjAiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxuXG4gIDxkaXYgaWQ9XCJhcHBcIj5cbiAgICA8ZGl2IHYtaWY9XCJlcnJvclwiPnt7ZXJyb3J9fX08L2Rpdj5cbiAgICA8U3VzcGVuc2U+XG4gICAgICA8dGVtcGxhdGUgI2RlZmF1bHQ+XG4gICAgICA8UXVpekxpc3QgPjwvUXVpekxpc3Q+XG4gICAgICA8L3RlbXBsYXRlPlxuICAgICAgPHRlbXBsYXRlICNmYWxsYmFjaz5sb2FkaW5nICAgcXVpemVzPC90ZW1wbGF0ZT5cbiAgICA8L1N1c3BlbnNlPlxuICA8L2Rpdj5cblxuICA8TWluaUNhcnQgdi1pZj1cImlzX2NhcnRfb3BlblwiPjwvTWluaUNhcnQ+XG48L3RlbXBsYXRlPlxuXG48c2NyaXB0PlxuLy8gQCBpcyBhbiBhbGlhcyB0byAvc3JjXG5pbXBvcnQgUXVpekxpc3QgZnJvbSBcIi4uL3ZpZXdzL3F1aXplcy9RdWl6ZXMudnVlXCI7XG5pbXBvcnQge3JlZiwgb25FcnJvckNhcHR1cmVkfSBmcm9tICd2dWUnXG5pbXBvcnQgTWluaUNhcnQgZnJvbSAnLi4vdmlld3Mvc2hvcC9NaW5pQ2FydC52dWUnXG5cblxuXG5leHBvcnQgZGVmYXVsdCB7XG4gIG5hbWU6IFwiSG9tZVwiLFxuICBjb21wb25lbnRzOiB7XG4gICAgUXVpekxpc3QsXG4gICAgTWluaUNhcnQsXG5cblxuXG4gIH0sXG4gIGRhdGEoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGlzVmlzaWJsZTogdHJ1ZSxcbiAgICAgIGVycm9yOiByZWYobnVsbCksXG4gICAgICBpc19jYXJ0X29wZW46IGZhbHNlO1xuICAgIH1cbiAgfSxcbiAgc2V0dXAoKSB7XG5cblxuICAgIG9uRXJyb3JDYXB0dXJlZCggZSA9PiB7XG4gICAgICB0aGlzLmVycm9yLnZhbHVlID0gZVxuICAgIH0pXG4gIH0sXG4gIG1ldGhvZHM6IHtcbiAgICBjaGFuZ2UoKSB7XG4gICAgICB0aGlzLmlzVmlzaWJsZSA9ICF0aGlzLmlzVmlzaWJsZVxuICAgIH1cbiAgfSxcbn07XG48L3NjcmlwdD5cblxuPHN0eWxlIHNjb3BlZD5cblxuXG5cbjwvc3R5bGU+Il0sIm1hcHBpbmdzIjoiOzs7OztBQUVBOzs7Ozs7QUFNQTtBQUNBOzs7Ozs7QUFQQTtBQUNBO0FBQUE7QUFFQTtBQUNBO0FBQUE7QUFFQTtBQUFBO0FBQUE7Ozs7QUFDQTtBQUdBO0FBQUE7OztBIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/Home.vue?vue&type=template&id=2f2be7e4\n");

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/Quizes.vue?vue&type=template&id=9b13c6a0":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/pug-plain-loader/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=template&id=adc7f09e&lang=pug":
false,

/***/ "./node_modules/core-js/internals/array-slice-simple.js":
false,

/***/ "./node_modules/core-js/internals/define-well-known-symbol.js":
false,

/***/ "./node_modules/core-js/internals/native-symbol-registry.js":
false,

/***/ "./node_modules/core-js/internals/object-get-own-property-names-external.js":
false,

/***/ "./node_modules/core-js/internals/path.js":
false,

/***/ "./node_modules/core-js/internals/symbol-define-to-primitive.js":
false,

/***/ "./node_modules/core-js/internals/well-known-symbol-wrapped.js":
false,

/***/ "./node_modules/core-js/modules/es.array.includes.js":
false,

/***/ "./node_modules/core-js/modules/es.json.stringify.js":
false,

/***/ "./node_modules/core-js/modules/es.object.get-own-property-symbols.js":
false,

/***/ "./node_modules/core-js/modules/es.string.includes.js":
false,

/***/ "./node_modules/core-js/modules/es.symbol.constructor.js":
false,

/***/ "./node_modules/core-js/modules/es.symbol.description.js":
false,

/***/ "./node_modules/core-js/modules/es.symbol.for.js":
false,

/***/ "./node_modules/core-js/modules/es.symbol.js":
false,

/***/ "./node_modules/core-js/modules/es.symbol.key-for.js":
false,

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/Quizes.vue?vue&type=style&index=0&id=9b13c6a0&lang=css":
false,

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=style&index=0&id=adc7f09e&lang=scss":
false,

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/quizes/Quizes.vue?vue&type=style&index=0&id=9b13c6a0&lang=css":
false,

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/shop/MiniCart.vue?vue&type=style&index=0&id=adc7f09e&lang=scss":
false,

/***/ "./views/quizes/Quizes.vue":
false,

/***/ "./views/quizes/Quizes.vue?vue&type=script&lang=js":
false,

/***/ "./views/quizes/Quizes.vue?vue&type=style&index=0&id=9b13c6a0&lang=css":
false,

/***/ "./views/quizes/Quizes.vue?vue&type=template&id=9b13c6a0":
false,

/***/ "./views/shop/MiniCart.vue":
false,

/***/ "./views/shop/MiniCart.vue?vue&type=script&lang=js":
false,

/***/ "./views/shop/MiniCart.vue?vue&type=style&index=0&id=adc7f09e&lang=scss":
false,

/***/ "./views/shop/MiniCart.vue?vue&type=template&id=adc7f09e&lang=pug":
false

})