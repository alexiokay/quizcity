webpackHotUpdate(7,{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/Profile.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader-v16/dist??ref--1-1!./views/accounts/Profile.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _Rankings_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Rankings.vue */ \"./views/accounts/Rankings.vue\");\n/* harmony import */ var _Rankings_vue__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Rankings_vue__WEBPACK_IMPORTED_MODULE_0__);\n\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  name: \"profile\",\n  components: {\n    Rankings: _Rankings_vue__WEBPACK_IMPORTED_MODULE_0___default.a\n  },\n  data: function data() {\n    return {};\n  },\n  methods: {\n    logout: function logout() {\n      window.location.href = \"http://localhost:8002/\" + \"accounts/logout\";\n    }\n  }\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvY2FjaGUtbG9hZGVyL2Rpc3QvY2pzLmpzPyEuL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4vbm9kZV9tb2R1bGVzL2NhY2hlLWxvYWRlci9kaXN0L2Nqcy5qcz8hLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci12MTYvZGlzdC9pbmRleC5qcz8hLi92aWV3cy9hY2NvdW50cy9Qcm9maWxlLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3ZpZXdzL2FjY291bnRzL1Byb2ZpbGUudnVlPzc4NzEiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxyXG4gIDxkaXYgPlxyXG4gICAgPHJvdXRlci12aWV3Pjwvcm91dGVyLXZpZXc+XHJcbiAgICA8ZGl2IHYtaWY9XCJ0aGlzLiRyb3V0ZS5uYW1lID09PSAnUHJvZmlsZSdcIj5cclxuICAgICAgVHV0YWogbmF2YmFyIHBvd2luaWVuIHBva2F6eXdhYyB0eWxrbyBlZGl0IHByb2ZpbGUgcG8gcHJhd2VqIGkgcG8gbGV3ZWpcclxuICAgICAgdG9nZ2xlciA8YnIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIHt7IHRoaXMuJHJvdXRlLm5hbWUgfX0gXHJcbiAgICAgIDxyb3V0ZXItbGluayA6dG89XCJ7bmFtZTogJ0ZyaWVuZHMnfVwiPllvdXIgZnJpZW5kczwvcm91dGVyLWxpbms+IDxicj5cclxuICAgICAgPCEtLSB1c2VybmFtZSAtLT5cclxuICAgICAgTmlja25hbWU6IHt7ICRzdG9yZS5zdGF0ZS51c2VyLnVzZXJuYW1lIH19IDxicj5cclxuXHJcbiAgICAgIDxhIEBjbGljaz1cImxvZ291dFwiPkxvZ291dDwvYT5cclxuICAgICBcclxuICAgICAgPCEtLSBidXR0b25zIC0tPlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDwhLS0gU2hhcmUgLS0+XHJcbiAgICAgICAgPCEtLSBGcmllbmRzIC0tPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICA8IS0tIHVzZXIgcGhvdG8gLS0+XHJcbiAgICAgICA8IS0tIGNoYWxsZW5nZXMgLS0+XHJcbiAgICAgICA8IS0tIGFtb3VudCBvZiBmcmllbmRzIC0tPlxyXG5cclxuICAgICAgPGhyIC8+XHJcblxyXG4gICAgICA8aDI+UmVzdWx0czwvaDI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cclxuICAgICAgICA8cD5DaGFsbGVuZ2VzPC9wPlxyXG4gICAgICAgIDxwPmRyZXc8L3A+XHJcbiAgICAgICAgPHA+bG9zdDwvcD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDwhLS0gQmFyIC0tPlxyXG4gICAgICAuLi4uLi4uLi4uLi4uXHJcblxyXG4gICAgICA8aHIgLz5cclxuXHJcbiAgICAgIDxoMj5CZXN0IGluPC9oMj5cclxuICAgICAgPFJhbmtpbmdzLz5cclxuICAgICAgPCEtLSBUYWJsZSB3aXRoIDYgY2F0ZWdvcmllcywgbGV2ZWxzIC0tPlxyXG5cclxuICAgICAgPGJ1dHRvbj5SYW5rczwvYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbiAgXHJcbiAgXHJcbiAgPC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0PlxyXG5pbXBvcnQgUmFua2luZ3MgZnJvbSBcIi4vUmFua2luZ3MudnVlXCJcclxuZXhwb3J0IGRlZmF1bHQge1xyXG4gIG5hbWU6IFwicHJvZmlsZVwiLFxyXG4gIGNvbXBvbmVudHM6IHtcclxuICAgIFJhbmtpbmdzLFxyXG4gIH0sXHJcbiAgZGF0YSgpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIFxyXG4gICAgfTtcclxuICB9LFxyXG4gICAgbWV0aG9kczoge1xyXG4gICAgICBsb2dvdXQoKSB7XHJcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBwcm9jZXNzLmVudi5WVUVfQVBQX1JPT1RfQVBJICsgXCJhY2NvdW50cy9sb2dvdXRcIlxyXG4gICAgfSxcclxuICB9LFxyXG59O1xyXG48L3NjcmlwdD5cclxuXHJcbjxzdHlsZT48L3N0eWxlPlxyXG4iXSwibWFwcGluZ3MiOiJBQWlEQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBVkEiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/Profile.vue?vue&type=script&lang=js\n");

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/Rankings.vue?vue&type=script&lang=js":
false,

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader-v16/dist/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/Rankings.vue?vue&type=template&id=52dfd827":
false,

/***/ "./node_modules/core-js/internals/advance-string-index.js":
false,

/***/ "./node_modules/core-js/internals/array-slice-simple.js":
false,

/***/ "./node_modules/core-js/internals/get-substitution.js":
false,

/***/ "./node_modules/core-js/modules/es.string.replace.js":
false,

/***/ "./node_modules/core-js/modules/es.string.split.js":
false,

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/Rankings.vue?vue&type=style&index=0&id=52dfd827&lang=css":
false,

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader-v16/dist/index.js?!./views/accounts/Rankings.vue?vue&type=style&index=0&id=52dfd827&lang=css":
false,

/***/ "./views/accounts/Rankings.vue":
/*!*************************************!*\
  !*** ./views/accounts/Rankings.vue ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi92aWV3cy9hY2NvdW50cy9SYW5raW5ncy52dWUuanMiLCJzb3VyY2VzIjpbXSwibWFwcGluZ3MiOiIiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./views/accounts/Rankings.vue\n");

/***/ }),

/***/ "./views/accounts/Rankings.vue?vue&type=script&lang=js":
false,

/***/ "./views/accounts/Rankings.vue?vue&type=style&index=0&id=52dfd827&lang=css":
false,

/***/ "./views/accounts/Rankings.vue?vue&type=template&id=52dfd827":
false

})